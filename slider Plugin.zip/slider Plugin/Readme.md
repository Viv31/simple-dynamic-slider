====dynamic Image Slider ====
Contributors:Vaibhav Gangrade
Requires at least: 4.0
Tested up to: 5.2
Version :1.0

== Description ==
This is a plugin for making Easy image simple slider where admin can set border ,time of image,number of images to show in slider.Plugin is fully responsive.


== How to Use ==

After installing plugin it will generate a shortcode [dynamic-Image-Slider] use this shortcode wherever you want to use.

== Requirements ==
it can run on any wordpress version it reqiores only html and css and some basic javascript.



Major features in Simpler Slider Plugin include:
	a) Can be changed border color dynamically.
	b) Can  be changed slider tme by admin options.
	c) Can be border width.
	d) Can be set numbers of images to show in slider.


	== Frequently Asked Questions == 

	 == Changelog == 

	  == Upgrade Notice == 

	  == Screenshots ==